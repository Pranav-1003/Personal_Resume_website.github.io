<?php

//get data from form 

$name = $_POST['name'];

$subjectS = $_POST['subjectS'];

$email= $_POST['email'];

$message= $_POST['message'];

$to = "pranavtotala12@gmail.com";

$subject = "Mail From Pranav";

$txt ="Name = ". $name . "\r\n Subject = " . $subjectS . "\r\n Email = " . $email . "\r\n Message =" . $message;

$headers = "From: file:///home/pranav/Pictures/Project/index.ht" . "\r\n" .

"CC: somebodyelse@example.com";

if($email!=NULL){

mail($to,$subject,$txt,$headers);

}

//redirect

header("Location:thankyou.html");

?>
